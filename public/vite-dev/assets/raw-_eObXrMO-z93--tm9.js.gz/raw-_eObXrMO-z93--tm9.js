import{g as d}from"./basedecoder-PFIibI7U-gdlnpIMU.js";class t extends d{decodeBlock(e){return e}}export{t as default};
