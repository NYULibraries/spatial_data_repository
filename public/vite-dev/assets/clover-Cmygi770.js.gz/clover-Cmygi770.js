import{C as e}from"./index-pmp42xxj-BdZL6jmq.js";document.addEventListener("DOMContentLoaded",()=>{new e().run()});
